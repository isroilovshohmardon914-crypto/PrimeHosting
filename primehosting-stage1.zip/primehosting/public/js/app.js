async function api(path, method = 'GET', body) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Xatolik yuz berdi');
  return data;
}

function el(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  Object.assign(e, props);
  kids.forEach(k => e.append(k));
  return e;
}

async function buildNav() {
  const nav = document.getElementById('nav');
  nav.append(el('a', { href: '/' }, 'Bosh sahifa'));
  try {
    await api('/api/me');
    nav.append(el('a', { href: '/dashboard.html' }, 'Dashboard'), el('a', { href: '/profile.html' }, 'Profil'));
    const out = el('a', { href: '#' }, 'Chiqish');
    out.onclick = async e => { e.preventDefault(); await api('/api/logout', 'POST'); location.href = '/'; };
    nav.append(out);
  } catch {
    nav.append(el('a', { href: '/login.html' }, 'Kirish'), el('a', { href: '/register.html', className: 'btn' }, 'Ro‘yxatdan o‘tish'));
  }
}

function bindAuthForm(id, endpoint, fields) {
  const form = document.getElementById(id);
  const err = document.getElementById('err');
  form.addEventListener('submit', async e => {
    e.preventDefault();
    err.textContent = '';
    const body = {};
    fields.forEach(f => (body[f] = form.elements[f].value));
    try { await api(endpoint, 'POST', body); location.href = '/dashboard.html'; }
    catch (ex) { err.textContent = ex.message; }
  });
}

function bar(label, used, total, unit) {
  const wrap = el('div');
  wrap.append(el('div', { className: 'muted' }, `${label}: ${used} / ${total} ${unit} (demo)`));
  const b = el('div', { className: 'bar' });
  b.append(el('i', { style: `width:${Math.min(100, (used / total) * 100)}%` }));
  wrap.append(b);
  return wrap;
}

async function loadServers() {
  const list = document.getElementById('servers');
  list.replaceChildren();
  const { servers } = await api('/api/servers');
  if (!servers.length) list.append(el('p', { className: 'muted' }, 'Hali server yo‘q. Pastdan yarating.'));
  servers.forEach(s => {
    const card = el('div', { className: 'card' });
    card.append(el('h3', {}, s.name + ' '), el('span', { className: 'badge' }, 'DEMO — haqiqiy server emas'));
    card.append(el('p', { className: 'muted' }, `Paper ${s.version} • O‘yinchilar: 0/20 (demo)`));
    card.append(bar('RAM', 0, s.ram_mb, 'MB'), bar('Disk', 0, s.disk_mb, 'MB'), bar('CPU', 0, 100, '%'));
    const del = el('button', { className: 'btn danger' }, 'O‘chirish');
    del.onclick = async () => { if (confirm('O‘chirilsinmi?')) { await api('/api/servers/' + s.id, 'DELETE'); loadServers(); } };
    card.append(del);
    list.append(card);
  });
}

async function initDashboard() {
  try { await api('/api/me'); } catch { location.href = '/login.html'; return; }
  const opts = await api('/api/options');
  const v = document.getElementById('version');
  opts.versions.forEach(x => v.append(el('option', { value: x }, x)));
  const r = document.getElementById('ram');
  opts.ram.forEach(x => r.append(el('option', { value: x }, x + ' MB')));
  document.getElementById('newServer').addEventListener('submit', async e => {
    e.preventDefault();
    const err = document.getElementById('err');
    err.textContent = '';
    try {
      await api('/api/servers', 'POST', { name: document.getElementById('name').value, version: v.value, ram: Number(r.value) });
      e.target.reset();
      loadServers();
    } catch (ex) { err.textContent = ex.message; }
  });
  loadServers();
}

async function initProfile() {
  try {
    const { user } = await api('/api/me');
    document.getElementById('pname').textContent = user.username;
    document.getElementById('pemail').textContent = user.email;
    document.getElementById('pdate').textContent = user.created_at;
  } catch { location.href = '/login.html'; }
}

function copyIp() {
  const ip = document.getElementById('ip').textContent;
  navigator.clipboard.writeText(ip).then(() => { document.getElementById('copyBtn').textContent = 'Nusxalandi!'; });
}

buildNav();
const page = document.body.dataset.page;
if (page === 'login') bindAuthForm('f', '/api/login', ['username', 'password']);
if (page === 'register') bindAuthForm('f', '/api/register', ['username', 'email', 'password']);
if (page === 'dashboard') initDashboard();
if (page === 'profile') initProfile();
