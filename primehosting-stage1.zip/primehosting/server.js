const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const VERSIONS = ['1.20.1', '1.20.4', '1.21.1'];
const RAM_OPTIONS = [512, 1024, 2048];
const MAX_SERVERS_PER_USER = 2;
const DISK_MB = 2048;

// Maxfiy kalit: birinchi ishga tushganda yaratiladi va data/ papkasida saqlanadi
const keyFile = path.join(__dirname, 'data', 'jwt.key');
if (!fs.existsSync(keyFile)) fs.writeFileSync(keyFile, crypto.randomBytes(48).toString('hex'));
const JWT_SECRET = fs.readFileSync(keyFile, 'utf8');

const app = express();
app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false });

function setSession(res, user) {
  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 3600 * 1000 });
}

function requireAuth(req, res, next) {
  try {
    const payload = jwt.verify(req.cookies.token, JWT_SECRET);
    const user = db.prepare('SELECT id, username, email, created_at FROM users WHERE id = ?').get(payload.id);
    if (!user) throw new Error('no user');
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: 'Avval tizimga kiring.' });
  }
}

app.post('/api/register', authLimiter, (req, res) => {
  const { username, email, password } = req.body || {};
  if (typeof username !== 'string' || !/^[A-Za-z0-9_]{3,16}$/.test(username))
    return res.status(400).json({ error: 'Foydalanuvchi nomi 3-16 ta harf, raqam yoki _ bo‘lsin.' });
  if (typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 100)
    return res.status(400).json({ error: 'Email noto‘g‘ri.' });
  if (typeof password !== 'string' || password.length < 8 || password.length > 72)
    return res.status(400).json({ error: 'Parol 8-72 belgi bo‘lsin.' });
  const exists = db.prepare('SELECT 1 FROM users WHERE username = ? OR email = ?').get(username, email.toLowerCase());
  if (exists) return res.status(409).json({ error: 'Bu nom yoki email band.' });
  const hash = bcrypt.hashSync(password, 12);
  const info = db.prepare('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)').run(username, email.toLowerCase(), hash);
  setSession(res, { id: info.lastInsertRowid });
  res.json({ ok: true });
});

app.post('/api/login', authLimiter, (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string')
    return res.status(400).json({ error: 'Ma’lumot to‘liq emas.' });
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash))
    return res.status(401).json({ error: 'Nom yoki parol noto‘g‘ri.' });
  setSession(res, user);
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

app.get('/api/me', requireAuth, (req, res) => res.json({ user: req.user, mode: 'demo' }));

app.get('/api/options', (req, res) => res.json({ versions: VERSIONS, ram: RAM_OPTIONS, diskMb: DISK_MB, maxServers: MAX_SERVERS_PER_USER }));

app.get('/api/servers', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT id, name, software, version, ram_mb, disk_mb, status, created_at FROM servers WHERE user_id = ? ORDER BY id DESC').all(req.user.id);
  res.json({ servers: rows });
});

app.post('/api/servers', requireAuth, (req, res) => {
  const { name, version, ram } = req.body || {};
  if (typeof name !== 'string' || !/^[A-Za-z0-9 _-]{3,24}$/.test(name))
    return res.status(400).json({ error: 'Server nomi 3-24 belgi (harf, raqam, bo‘shliq, _ yoki -).' });
  if (!VERSIONS.includes(version)) return res.status(400).json({ error: 'Versiya noto‘g‘ri.' });
  if (!RAM_OPTIONS.includes(ram)) return res.status(400).json({ error: 'RAM tanlovi noto‘g‘ri.' });
  const count = db.prepare('SELECT COUNT(*) AS c FROM servers WHERE user_id = ?').get(req.user.id).c;
  if (count >= MAX_SERVERS_PER_USER) return res.status(400).json({ error: `Maksimum ${MAX_SERVERS_PER_USER} ta server.` });
  db.prepare('INSERT INTO servers (user_id, name, version, ram_mb, disk_mb) VALUES (?, ?, ?, ?, ?)').run(req.user.id, name.trim(), version, ram, DISK_MB);
  res.json({ ok: true });
});

// Faqat o'z serverini o'chira oladi (user_id tekshiriladi)
app.delete('/api/servers/:id', requireAuth, (req, res) => {
  const info = db.prepare('DELETE FROM servers WHERE id = ? AND user_id = ?').run(Number(req.params.id), req.user.id);
  if (!info.changes) return res.status(404).json({ error: 'Server topilmadi.' });
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`PrimeHosting ishga tushdi: http://localhost:${PORT}  (DEMO rejim)`));
